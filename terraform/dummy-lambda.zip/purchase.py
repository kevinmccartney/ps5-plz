def lambda_handler():
  print("Hello, world!")